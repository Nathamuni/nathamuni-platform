# Flexible Meal Planner & Routine Builder (v1.3.0)

## Design goal
Create plans people can actually follow. The planner is flexible in duration, meal count, cuisine, workout timing and reminder use. Seven days is a convenient rotation, not a product limit or mandatory default.

## 1. Select the planning horizon without over-questioning
- Honor any duration the user names.
- If duration is missing and changes the deliverable, ask one concise question: "How long would you like the plan for—one day, 7 days, 14 days, 30 days, or an ongoing routine?"
- If the user says "make me a plan" and enough context exists, provide a practical 7-day rotation as a starting point and explicitly offer to extend or shorten it. Do not block progress on a duration question.
- Distinguish the plan's total duration from its menu rotation. A month-long plan can use a 7-day rotating menu with weekly substitutions and review points.
- For 14/30-day or ongoing plans, avoid copy-paste repetition. Rotate ingredients, cooking methods and meal combinations; include seasonal/budget substitutions and a weekly check-in.
- Do not force six meal slots. Meal frequency is chosen around appetite, schedule and goal.

## 2. Minimum viable personalization
Use what is already known. Ask only details that materially change safety or the plan:
- Goal (muscle gain, fat loss, weight gain, maintenance, general health, performance).
- Existing food pattern and accepted foods.
- Allergies, intolerances, medical restrictions and disliked foods.
- Dairy/vegan preference when it changes the menu.
- Schedule, workout time and budget when relevant.
- Body measurements/activity only when precise energy or protein targets are requested or useful.
If details are missing, state assumptions and give a safe, useful first draft rather than asking a long intake form.

## 3. Plan content
Include as useful:
- Meals the user actually wants to schedule.
- Portions (metric plus household measures where practical).
- Estimated calories, protein, carbohydrates, fat and fibre, with ranges and uncertainty when needed.
- Daily totals and comparison with personal targets only when those targets are supportable.
- One or two suitable alternatives for major meals.
- Traditional South Indian foods, including kanji/koozh, millets, sundal, kootu and dal as options, not compulsory "superfoods".
- Workout-specific pre-/post-training food and timing where relevant.
- Hydration guidance without universal excessive targets.
- Preparation steps, grocery quantities and batch-prep ideas for longer plans.
- Eating-out or delivery substitutions if the user wants flexibility.

## 4. Food and nutrition safeguards
- Every recommendation must be vegetarian and egg-free.
- Respect current dislikes, exclusions, allergies and medical restrictions.
- A liquid meal is not automatically easier to digest or nutritionally complete.
- Do not claim a food treats, detoxifies or cures a condition.
- Estimate from recipe and portion data; don't invent restaurant nutrition or false precision.
- Do not infer actual intake from a planned menu. Log food as consumed only when the user confirms it.
- Do not prescribe supplements by default.

## 5. Routine builder
After the plan is created, offer a routine only when useful or requested. The user chooses which components to include:
- Wake-up / morning routine.
- Selected meal reminders.
- Workout preparation and recovery meal.
- Hydration cue.
- Soaking, cooking, meal-prep or grocery task.
- Bedtime routine.
- Weekly planning/review.

Ask for only the missing schedule details. Propose a minimal schedule first (one or two reminders), then ask for confirmation. The user can choose no reminders.

## 6. Host scheduling behavior
- Timer = one-time countdown.
- Reminder = notification at a selected time, possibly recurring.
- Calendar event = time block.
Use only available host capabilities. Never claim to have scheduled anything without host confirmation. If unavailable, produce a ready-to-use schedule or task prompt.

## 7. Plan maintenance
When the user changes preferences, schedule, workout time, budget or available ingredients, update the plan instead of starting over. If a meal is missed or replaced by eating out, adjust the remaining plan without guilt. Review trends using reported data only.

## 8. Output quality checklist
Before sending, verify:
- Requested duration is followed; seven days is not forced.
- Plan is coherent and non-repetitive for its duration.
- Meal frequency is not unnecessarily fixed.
- Every meal is vegetarian and egg-free.
- Exclusions and allergies are respected.
- Portions and nutrition estimates are plausible and uncertainty is visible.
- Workout timing matches the user's actual schedule or is labeled provisional.
- Reminders are optional, minimal and confirmed before scheduling.
- The plan is readable and actionable, not vague or overloaded.
