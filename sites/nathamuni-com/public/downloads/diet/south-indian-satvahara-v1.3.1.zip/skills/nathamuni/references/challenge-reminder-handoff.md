# Challenge, Routine & Reminder Handoff (v1.3.0)

## Purpose
Turn a personalized nutrition plan into a usable, user-led routine. This is a coaching protocol, not medical treatment or automatic activity tracking. Plan duration and reminder frequency are chosen by the user; seven days is not a mandatory limit.

## Plan duration vs. reminder duration
- Ask the preferred plan horizon only when it is unknown and relevant: one day, 3/7/14/30 days, a month, or ongoing/repeatable.
- A 7-day rotating menu may serve as a reusable base for a longer plan, but do not force a 7-day plan when the user asks for another duration.
- Keep plan length separate from reminder duration. A user may request a 30-day meal plan but only a 7-day reminder routine, or no reminders at all.
- For long horizons, use a repeatable meal rotation, weekly variation and review points rather than padding the plan with repetitive entries.

## Routine builder
1. Start from the user's existing meal plan, wake/sleep times, work/study routine, workout schedule and preferred meal occasions.
2. Offer optional routine components: wake-up cue, chosen meal reminders, pre-/post-workout cue, hydration cue, meal prep/soaking/grocery reminder, bedtime wind-down and weekly review.
3. Ask only for missing details that affect scheduling: which reminders, preferred time(s), days/frequency, start date or duration, and timezone if unclear.
4. Recommend the smallest useful schedule (usually one or two reminders initially). Never schedule every meal by default.
5. Show the proposed routine clearly and obtain explicit confirmation before creating any task, notification or calendar event.
6. Let the user edit, pause or stop the routine. Adapt it when their schedule changes.

## Timer vs reminder vs calendar event
- **Timer:** a one-time countdown (e.g., 15 minutes to soak or steep something).
- **Reminder:** a notification at a chosen time, potentially recurring (e.g., breakfast at 8 AM).
- **Calendar event:** a time block (e.g., workout from 6:30–7:15 AM).
Do not conflate these capabilities. Use only the actual host feature available.

## Challenge cycle
1. Choose one focus based on the user's goal or an observed pattern.
2. Choose duration with the user; suggest 3/7/14/21/30 days only as options, not a fixed sequence.
3. Set a measurable, non-punitive baseline when useful.
4. Give one practical daily mission with a clear success definition and optional easier version.
5. Invite `done`, `partly`, or `missed` check-ins only if the user wants accountability.
6. Adapt the next mission without guilt, forced restarts or punitive streak language.
7. Review only user-reported information at the chosen interval.
8. Finish with a useful summary and next step; do not automatically create another challenge.

## Reminder defaults and notification hygiene
- Reminders are opt-in. A plan does not automatically authorize notifications.
- Start with one or two high-value reminders chosen by the user; do not create a full series of meal alerts by default.
- A weekly recap is optional and separate.
- Respect quiet hours, sleep, work, travel, fasting and variable workout schedules.
- Do not send duplicate or excessive notifications.
- A reminder is a nudge, not proof that the user ate, drank water, exercised or completed a task.
- Never claim to monitor activity or completion outside user check-ins.

## Capability boundary
Use a supported host scheduling tool only when it is actually available and authorized. Obtain explicit confirmation of the exact schedule before creating anything. Never say a timer, reminder, task or calendar event was created until the host confirms success.

If creation is unavailable in the current plugin/chat:
- State the limitation briefly.
- Give the user a ready-to-use schedule or copy/paste task prompt with the chosen times, days, timezone, duration and reminder behavior.
- Do not make the user reconstruct the plan from scratch.
- Do not repeatedly offer the same reminder setup after a decline.

## Ready-to-use task prompt
"Help me follow my [plan/challenge] for [duration]. At [selected time(s) and timezone] on [selected days], send only these reminders: [chosen routine items]. Keep notifications quiet and limited. Respect my vegetarian and egg-free requirements, food exclusions, allergies, preferences, sleep and work schedule. Ask me to report completion only if I opt into check-ins. At [review interval], summarize only what I have reported and suggest one practical adjustment. Do not claim to observe my meals, hydration or workouts."

## Safety
Do not create calorie restriction, fasting, weigh-in or exercise challenges that may be unsafe. Use additional caution for pregnancy/lactation, minors, eating-disorder risk, chronic illness, significant symptoms, abnormal labs or clinician-prescribed diets. Encourage qualified clinical guidance when needed.
