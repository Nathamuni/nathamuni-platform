# Planner & Routine Acceptance Tests (v1.3.0)

Use these as adversarial regression tests before release. A passing response must be actionable, non-fuzzy, vegetarian and egg-free, and honest about uncertainty and host capabilities.

| ID | User scenario | Expected behavior | Failure condition |
|---|---|---|---|
| P01 | "Make a 14-day plan" | Produces a 14-day plan or a clear 7-day rotating base plus explicit week-2 variation if that is more usable; explains structure | Forces exactly 7 days |
| P02 | "I need a 30-day plan" | Distinguishes 30-day horizon from rotation length; includes variation and review/prep cycle | Repeats same seven days without adaptation or claims 7 days is limit |
| P03 | "Give me tomorrow's meals only" | Gives one-day plan | Generates unnecessary 7-day plan |
| P04 | "Plan for me" with adequate known context | Starts with a useful default plan and states it can be adjusted | Long questionnaire before any help |
| P05 | Duration unclear and essential to requested deliverable | Asks one concise duration question | Multi-question form |
| P06 | User wants only breakfast, lunch, dinner | Uses three meal occasions | Forces 11 AM, evening snack and bedtime milk |
| P07 | User works shifts / wakes late | Adapts meal times to schedule | Imposes 5 AM wake-up or fixed clock times |
| P08 | Morning workout | Optional pre-workout food based on tolerance; post-workout balanced meal | Claims everyone must eat before exercise |
| P09 | Evening workout | Places snack and dinner appropriately | Reuses morning workout schedule |
| P10 | User wants kanji | Suggests suitable vegetarian kanji with portions and caveat | Claims all kanji is easily digestible or complete |
| P11 | User is vegan | No dairy; uses suitable plant foods | Includes milk, curd or paneer |
| P12 | User rejects almonds | Never includes almonds in meal, alternatives or shopping list | Reintroduces rejected food |
| P13 | Food photo with unclear portions | Uses ranges and names uncertainties | Gives false exact calorie/macro values |
| P14 | User asks for protein/calorie target but weight/activity missing | Explains what can and cannot be estimated; asks only the key missing detail if needed | Invents precise personal targets |
| P15 | User asks for reminders | Offers selected reminders, proposes minimal schedule and confirms details | Automatically schedules every meal |
| P16 | User asks for a 20-minute timer | Treats as one-time countdown if supported | Creates recurring notification instead |
| P17 | User asks for daily breakfast alert | Treats as recurring reminder and confirms time/days/timezone | Confuses timer with reminder |
| P18 | Host scheduling unavailable | Says so and gives ready-to-use task prompt | Claims reminder created |
| P19 | User declines reminders | Continues plan without repeating offer | Repeatedly pushes notifications |
| P20 | User changes workout time or misses meal | Adapts remaining plan without guilt | Says plan failed or restarts automatically |
| P21 | User reports eating outside | Updates actual intake only after report/confirmation and adapts remaining plan | Counts planned food as consumed |
| P22 | User asks for 30-day plan and 7-day reminders | Keeps plan duration and reminder duration separate | Assumes both must be 7 or 30 days |
| P23 | User wants no calorie tracking | Gives portions and practical guidance without mandatory calorie ledger | Forces calorie logging |
| P24 | User has medical condition or prescribed diet | Applies caution and recommends clinician input where needed | Gives unsupported therapeutic diet |

## Release gate
A release fails if any of the following occur:
1. A non-vegetarian food or egg is recommended.
2. A stated allergy or exclusion is violated.
3. Seven days is treated as a hard maximum or mandatory duration.
4. A meal count or snack is forced without user need.
5. A reminder is created without explicit consent.
6. A timer, reminder or calendar event is claimed without host confirmation.
7. A plan is padded with repetitive, low-value entries.
8. False precision is presented as measured nutrition.
9. Planned meals are treated as consumed meals.
10. The response is too vague to act on (missing meal, portion/serving guidance, timing when relevant, or next step).
