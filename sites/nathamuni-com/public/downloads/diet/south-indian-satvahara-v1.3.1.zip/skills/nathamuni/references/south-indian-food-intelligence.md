# South Indian food and diet reference (vegetarian, egg-free)

Reference data for the Nathamuni skill. Everything here is vegetarian and egg-free, in line with `vegetarian-only-policy.md`. Nutrient values and portions are estimates; say so when giving numbers.

Contents: 1 Foods · 2 Meal combinations · 3 Supplements · 4 Nutrient gaps · 5 Meal timing · 6 Goal templates · 7 Example muscle-gain day · 8 Specialist topics

---

## 1. South Indian foods

Recognize regional differences (Tamil Nadu, Kerala, Karnataka, Andhra, Telangana). Do not assume all South Indians eat the same foods.

### Millets and traditional grains

| Grain | Typical uses |
|---|---|
| Ragi (finger millet) | Ragi dosa, mudde, koozh, porridge, puttu, adai |
| Thinai (foxtail millet) | Pongal, upma, cooked grain |
| Samai (little millet) | Rice-style meals, pongal, mixed dishes |
| Varagu (kodo millet) | Rice-style meals, vegetable meals, pongal |
| Kuthiraivali (barnyard millet) | Upma, pongal, cooked grain |
| Kambu (pearl millet) | Koozh, dosa, porridge, rotis |
| Cholam (sorghum) | Dosa, roti, flour-based dishes |
| Traditional rice varieties | Red rice, brown rice, parboiled rice, hand-pounded rice |

Guidance:
- Millets are useful but not automatically better than rice for every person.
- Choose grains by need, tolerance, availability, cost, cooking time and enjoyment.
- Millets do not inherently cause weight loss. For fat loss, portion balance and total intake matter more than swapping rice for millet.
- For muscle gain, millets fit well if energy and protein are sufficient.
- Rotate grains; relying on a single millet is not ideal.
- Millet-heavy diets in people with very restrictive eating or thyroid-related concerns need attention to variety and adequacy, and a clinician's input where relevant.

### Sundal, pulses and legumes

| Food | Practical uses |
|---|---|
| Kondakadalai (chickpeas) | Sundal, channa masala, salads |
| Karuppu kondakadalai (black chana) | Sundal, snacks |
| Pachai payaru (green gram) | Sprouts, sundal, dosa, kootu |
| Paasi paruppu (moong dal) | Pongal, kootu, soup, dosa |
| Karamani (cowpeas) | Sundal, curry, kuzhambu |
| Kollu (horse gram) | Rasam, sundal, chutney |
| Rajma | Curry, meal bowls |
| Thuvaram paruppu (toor dal) | Sambar, dal, kootu |
| Ulundhu (urad dal) | Idli, dosa, adai |
| Kadalai paruppu (chana dal) | Kootu, other chana-dal dishes |
| Soybeans | Curries, snacks, soy milk |
| Soy chunks | Protein-rich curries, pulao |
| Tofu, tempeh | Stir-fries, curries, bhurji, fillings |
| Peanuts | Chutney, sundal, snacks, added to meals |

Sundal questions to be ready for: which sundal suits my goal, how much to eat, whether it meets my protein need, what to pair it with, before or after a workout, how to make it for weight gain or fat loss, cheapest high-protein option, daily use, and which pulses to rotate. Rotate chickpeas, green gram, cowpeas, peanuts and other legumes rather than repeating one snack. Do not overstate the protein in small snack portions.

### Vegetables and greens

Greens (keerai): murungai keerai (moringa leaves), arai keerai (amaranth), siru keerai (small amaranth), ponnanganni (alternanthera), venthaya keerai (fenugreek leaves), palak (spinach), manathakkali keerai (black nightshade), vallarai (gotu kola).

Other vegetables: drumstick, carrot, beetroot, beans, cluster beans, cabbage, cauliflower, pumpkin, ash gourd, bottle gourd, snake gourd, ridge gourd, brinjal, okra, tomato, onion, mushroom, raw banana and plantain, sweet potato.

Choose by nutrient diversity, fiber, cooking method, season, goal, digestive tolerance, cost and whether the person is eating enough overall. Suggest poriyal, kootu, avial, vegetable sambar, soups and stir-fries rather than a generic "eat more vegetables".

### Fruits, juices and hydration

Cover banana, guava, papaya, orange, mosambi, mango, watermelon, muskmelon, pomegranate, sapota, jackfruit, pineapple, amla, apple, grapes and seasonal local fruit.

Default to whole fruit over juice because it keeps its fiber and is usually more filling. Juice is not forbidden; portion, added sugar and goal matter. Never present juice as a detox, a fat burner or a meal replacement.

| Goal | Fruit strategy |
|---|---|
| Fat loss | Whole fruits, filling choices, portions that fit |
| Weight gain | Fruit plus milk, curd, nuts or other energy-dense foods (plant-based if vegan) |
| Muscle building | Convenient pre-workout carbohydrate or additions to meals |
| General health | Variety of whole fruits across the week |
| Workout recovery | Fruit with a protein source when useful |
| Hydration | Water first; fruit adds fluid but does not replace it |

---

## 2. Meal combinations

Never judge a dish in isolation. A meal can be fine while the whole day still lacks protein, energy, vegetables or variety. Optimize the dish; do not label it "bad".

| Meal | How to optimize |
|---|---|
| Idli + sambar | Adjust sambar quantity; add a legume or tofu/paneer side where needed |
| Dosa + chutney | Add a dal or sundal side, or a filling such as tofu bhurji or paneer |
| Pesarattu | Green gram base gives useful protein; pair with vegetables |
| Adai | Multi-pulse dish; portion and sides depend on goal |
| Rice + sambar | Raise the dal portion, add vegetables and a protein side |
| Rice + kootu + poriyal | Balance the plate and protein |
| Curd rice | Recognize the curd contribution; add vegetables and a protein-rich side if more is needed (plant yogurt for vegans) |
| Pongal | Consider rice, dal, added fat, portion and sides |
| Chapati + channa | Check total portions and adequacy |
| Lemon rice | Mainly carbohydrate; add legumes and vegetables |
| Tamarind rice | Build the meal around it instead of calling it bad |
| Upma | Add legumes, soy, or dairy where accepted |
| Puttu | Pair with kadala curry, green gram or other legume sides |
| Kambu koozh | Traditional preparation; build an adequate meal around it |
| Rasam rice | Add protein and vegetables if the meal is light |

---

## 3. Supplements (vegetarian and vegan suitable only)

Ask first: does this person need a supplement, can food meet the need, and is it safe for their context? Never recommend a stack just because someone works out.

| Supplement | Purpose | How to handle |
|---|---|---|
| Plant protein (pea, soy, rice, blends) | Convenience when food falls short | Compare protein per serving, digestibility, additives, cost per gram of protein |
| Whey | Dairy users only; not vegan | Only for users who consume dairy, and only when food intake is inconvenient or insufficient |
| Creatine monohydrate | Strength and repeated high-intensity work | Explain evidence, typical use, contraindications; check the product for animal-derived additives |
| Vitamin B12 | Prevent or correct deficiency, especially on vegan diets | Emphasize a reliable supplement or fortified food; assess risk for lacto-vegetarians too |
| Vitamin D | Inadequate status or specific risk | Consider testing and clinician-guided dosing |
| Iron | Treat or prevent deficiency when indicated | Not routine; needs assessment |
| Algal omega-3 (DHA/EPA) | When supplementation is appropriate | Vegetarian and vegan source; never fish oil |
| Calcium | Bone health and adequacy | Assess food and total intake first |
| Zinc | Inadequate intake or deficiency | Avoid excessive or long-term high doses |
| Electrolytes | Heat, long exercise, heavy sweat | Plain water is usually enough for ordinary activity |
| Caffeine | Performance, alertness | Optional; consider sleep, anxiety, heart conditions, timing |
| Multivitamin | Fill selected gaps | Not a substitute for a balanced diet |
| Psyllium | Fiber intake or bowel-related needs | Consider hydration, tolerability, medication timing |

Decision pathway: define the goal → assess food intake and context → identify the real gap (convenience, intake, possible deficiency, evidence-based performance) → decide: food first, supplement if useful, medical evaluation if needed, or no supplement.

Quality checks for any product: ingredient transparency, dose per serving, third-party testing when verifiable, contamination risk, proprietary blends, excessive doses, unsupported claims, counterfeit risk, suitability for the user's diet and health. For competitive athletes, prefer independently certified sports supplements.

---

## 4. Nutrient gaps on a vegetarian or vegan diet

Identify dietary risk, do not diagnose. Symptoms alone never establish a deficiency ("you are tired" is not "you have iron deficiency"); suggest testing or clinician review where warranted.

| Nutrient | Vegetarian and vegan sources and considerations |
|---|---|
| Protein | Pulses, legumes, soy, tofu, tempeh, dairy (if accepted), nuts, seeds |
| Iron | Legumes, greens, seeds, fortified foods; pair with vitamin C |
| Vitamin B12 | Dairy (if accepted), fortified foods, reliable supplement; essential to plan for on vegan diets |
| Vitamin D | Sun exposure context, fortified foods, supplementation when indicated |
| Calcium | Dairy (if accepted), calcium-set tofu, ragi, selected greens, fortified plant milks |
| Zinc | Pulses, seeds, nuts, whole grains |
| Iodine | Iodized salt, dairy depending on intake; avoid excess seaweed |
| Folate | Greens, legumes, vegetables |
| Omega-3 | Flaxseed, chia, walnuts (ALA); algal oil for DHA/EPA |
| Fiber | Whole grains, millets, pulses, fruit, vegetables, seeds |
| Potassium | Fruit, vegetables, legumes, tubers |
| Magnesium | Legumes, nuts, seeds, whole grains, greens |
| Vitamin C | Guava, amla, citrus, other fruit and vegetables |
| Vitamin A | Carrot, pumpkin, greens, other colourful vegetables |
| Choline | Soy, selected legumes, whole grains |
| Thiamin | Whole grains, legumes, seeds, fortified foods |
| Riboflavin | Dairy (if accepted), selected legumes, greens, fortified foods |

Risk patterns to watch:
- Vegan diet: reliable B12; also calcium, iodine, zinc, iron, omega-3.
- Low-variety vegetarian diet: protein, iron, B12, calcium, zinc.
- Low food intake: overall energy and nutrient adequacy.
- Heavy training with too little food: possible underfueling.
- Little fruit and vegetables: fiber, vitamin C, folate, potassium.
- Little dairy or fortified food: calcium, B12, vitamin D, protein.
- Low sun exposure: vitamin D.
- Heavy sweating in heat: fluid and electrolytes.
- Older adult with poor appetite: protein, total intake, B12, vitamin D, calcium, hydration.

---

## 5. Meal timing templates

Do not force six meals. Pick a pattern the person can sustain, and adapt to shifts, college, fasting, travel and irregular schedules.

**A. Normal daytime routine**

| Time | Meal | Example |
|---|---|---|
| 7:00–8:30 AM | Breakfast | Idli + sambar, adai, pesarattu, or tofu bhurji with dosa |
| 10:30–11:30 AM | Optional snack | Fruit, milk or soy milk, sundal, curd |
| 1:00–2:00 PM | Lunch | Rice + sambar/kootu + vegetables + protein source |
| 4:30–5:30 PM | Evening snack | Sundal, fruit, curd, milk, or a plant protein shake |
| 7:30–9:00 PM | Dinner | Dosa, chapati or rice with vegetables and a protein source |
| Before bed | Optional | Milk or curd (or soy milk) if needed to meet intake |

**B. Early morning workout**: water, with a small snack only if hungry; afterwards a normal breakfast with protein and carbohydrate; then balanced lunch, snack as needed, normal dinner.

**C. Evening workout**: balanced breakfast and lunch; a meal or snack 60–180 min before training depending on comfort; dinner with protein and carbohydrate afterwards; adjust late-night portions to avoid heavy fullness.

**D. Weight gain**: three main meals plus one or two extra eating occasions if helpful; raise portions gradually; add energy-dense foods such as milk or curd (or soy milk), banana, peanuts, sesame and legumes; a shake only when useful.

**E. Fat loss**: a sustainable structure with filling foods, adequate protein, vegetables, fruit and fiber; no mandatory meal skipping; keep enough fuel for training and daily activity.

---

## 6. Goal templates

| Goal | Focus |
|---|---|
| Fat loss | Sustainable deficit if appropriate; protein at meals; vegetables, fruit, fiber; portion awareness; preserve strength; track trends, not daily swings |
| Weight gain | Gradual surplus; larger portions; extra snacks; energy-dense nutritious foods; monitor appetite and progress |
| Muscle building | Adequate energy; protein target and distribution; carbohydrate support; progressive training; recovery |
| Body recomposition | Strength progression; adequate protein; avoid excess restriction; adjust to real progress |
| Maintenance | Adequate nutrition; meal balance; variety; consistency; enjoyment |

Adapt for underweight, overweight, medical conditions, beginners, experienced athletes and very low budgets. Do not assign a deficit or surplus from a single BMI value.

---

## 7. Example vegetarian muscle-building day

Illustrative structure only; quantities and protein totals depend on the person.

- **7:30 AM breakfast**: pesarattu or adai with chutney, plus an extra protein source if needed (tofu bhurji, curd or soy milk).
- **10:30 AM snack**: banana, milk or curd (or soy milk), or nuts, depending on energy and protein needs.
- **1:00 PM lunch**: rice, sambar or dal, kootu, vegetables, curd, plus another protein source if needed.
- **4:30 PM pre-workout snack**: sundal, fruit, or another easily tolerated carbohydrate-plus-protein combination.
- **7:30–9:00 PM dinner**: dosa, chapati or rice with vegetables and a meaningful protein source (paneer, tofu, soy chunks or a legume dish).
- **Before bed (optional)**: milk, curd or a small snack if it helps meet the day's intake.

For fat loss, reduce quantities and energy density within the same familiar framework. For vegan users, replace dairy with soy milk, soy yogurt, tofu or legumes, and address B12. Rearrange for different training times.

---

## 8. Specialist topics

Fasting and religious food practices · food allergies and intolerances · digestive comfort and gradual fiber increases · sleep and meal routine · shift-work, college and office nutrition · travel · family meal planning · cooking for one or for a family · food safety and leftovers · seasonal foods · food labels · emotional eating and eating-disorder-aware responses · vegetarian protein combinations · vegan supplementation · healthy substitutions · managing cravings without unnecessary restriction.

Organic food is fine if the user prefers it and can access it, but do not claim it is nutritionally superior. Prioritize safe, varied, affordable, adequate food, and encourage washing produce.
