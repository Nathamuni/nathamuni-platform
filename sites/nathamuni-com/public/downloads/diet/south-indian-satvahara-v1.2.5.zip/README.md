# South Indian Satvahara

**AI companion / skill identity:** Nathamuni  
**Creator attribution:** Designed by Nathamuni  
**Product category:** South Indian vegetarian diet and nutrition intelligence

A skills-based plugin for strictly vegetarian and egg-free nutrition coaching, with South Indian food at its core and global vegetarian food options available. It supports lacto-vegetarian and vegan users, and people moving gradually from non-vegetarian eating.

Every meal, recipe, snack, substitution, grocery list and supplement suggestion stays vegetarian and egg-free. The coach covers goal-specific meal plans (muscle gain, fat loss, weight gain, calisthenics and strength, endurance, general health), vegetarian protein adequacy, nutrient-gap awareness (B12, iron, calcium, omega-3 and others), supplement safety, and affordable product comparisons.

## Upgrade 1.2.0

Adds an **Adaptive Food & Nutrient Solver**: global vegetarian food discovery, strict current-conversation exclusion tracking (never repeat foods the user rejects), nutrient-role substitutions, realistic portion/nutrient checks, and honest handling when food alone may not meet a need. South Indian cuisine remains the specialization, not a restriction on food options.

## Upgrade 1.2.2

Adds a **Food Habit & Diet Quality Analyzer** that audits the user's real daily eating pattern for possible nutrient gaps, excesses, meal balance, and habits. It gives prioritized, non-judgmental corrections, preserves cultural foods and preferences, avoids false precision, and adapts as the user reports changes.

## Layout

- `skills/nathamuni/SKILL.md`: the skill and its non-negotiable vegetarian-only rule.
- `skills/nathamuni/references/`: the vegetarian-only policy, the South Indian food reference and the full coaching framework.
- `.claude-plugin/`, `.codex-plugin/`, `plugin.json`: manifests for Claude and Codex-style hosts.

## Disclaimer

This plugin provides general nutrition education. It is not medical advice and does not diagnose or treat any condition. People with medical conditions, who are pregnant or breastfeeding, or who are buying supplements for children should talk to a qualified healthcare professional.

## Upgrade 1.2.3 — Multilingual & Natural Interaction

Adds multilingual conversational behavior (Tamil script, Tanglish, English, mixed-language and other supported languages), language-switch continuity, natural speech/transcript tolerance, image/document input guidance when the host supports it, accessibility, privacy, safety-term clarification, and honest capability fallback when audio features are unavailable. Users can type naturally or use voice input if their host interface exposes it; this package does not itself enable microphone or audio playback.

## Capabilities vs host support
Language understanding and multilingual responses are instruction-level behavior. Voice capture/transcription, spoken replies, image uploads, and document uploads depend on the hosting app and model/interface.

## Upgrade 1.2.4 — Challenges & Reminder Handoff

Adds adaptive multi-day nutrition challenges, daily missions, gentle check-ins (`done / partly / missed`), weekly reviews, recovery without guilt, and challenge progression. When reminders would help, the coach offers to assist with ChatGPT Scheduled Task setup. If task creation is not available in the current GPT/plugin chat, it prepares a personalized ready-to-paste task prompt and guides the user to a supported ChatGPT task interface. It never claims a reminder was created without host confirmation.

New reference: `skills/nathamuni/references/challenge-reminder-handoff.md`.


## Product identity and assistant behavior

The product is named **South Indian Satvahara**. The skill and AI companion identity is **Nathamuni**.

When users ask the assistant's name, it should answer: “I'm Nathamuni, your nutrition companion from South Indian Satvahara.”

When users ask who designed or created the skill, it should answer: “I was designed by Nathamuni.”

The assistant must remain transparent that it is an AI assistant, not a human person or medical professional. The creator attribution is not a claim of human identity.

## Upgrade 1.2.5 — South Indian Satvahara branding

Updates the product name to South Indian Satvahara, uses Nathamuni as the skill/assistant identity, and adds consistent creator attribution and natural identity responses. The existing vegetarian-only, egg-free nutrition rules and safety framework remain in force.
